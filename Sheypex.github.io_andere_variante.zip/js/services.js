'use strict';

/* Services */


// Demonstrate how to register services
// In this case it is a simple value service.
angular.module('myAppServices', ['ngResource'])
    .factory('getApiData', ['$resource',
        function ($resource) {
            return $resource('http://www.omdbapi.com/',
                {callback:'JSON_CALLBACK'},
                {
                    fetchJSONP: {method: 'JSONP'/*, params: {s: 'TITLE', i: '', t: '', y: '2000', r: 'JSON', plot: 'simple', callback: 'JSON_CALLBACK', tomatoes: 'false'}*/,
                                 isArray: false}
                })
    }]);
