'use strict';

/* Directives */


angular.module('myAppDirectives', ['myAppServices'])
    .directive('insertFooter', function () {
        return {
            restrict: 'E',
            template: '<hr />' +
                '<div class="grid_12 alpha omega">' +
                '<a href="http://de.cooltext.com" target="_top">' +
                '<img src="http://cooltext.com/images/ct_pixel.gif" width="80" height="15" alt="Cool Text: Logo und Grafik-Generator" border="0" />' +
                '</a>' +
                '</div>' +
                '<div class="grid_12 alpha omega">' +
                '<p style="float:left; margin-bottom:10px">No Copyright &copy; 2014 No rights reserved. Use anything you might find useful if you so desire :)</p>' +
                '<p style="float:right; margin-bottom:10px">Thanks for visiting.</p>' +
                '</div>'
        }
    })
    .directive('insertWIP', function () {
        return {
            restrict: 'E',
            template: '<h1>Sorry,</h1>' +
                '<h4>but this section is still work in progress :(</h4>' +
                '<h4>Please come back soon if you\'re interested though.</h4>'
        }
    })
    .directive('omdbapiQueryDataInsertion', function (getApiData) {
        return {
            restrict: 'E',
            /*scope: {
             titleToSearch: '=',
             yearToSearch: '=',
             plotToSearch: '@'
             },*/
            transclude: true,
            template: '<div class="wrapper grid_12 alpha omega" ng-transclude></div>',
            controller: function ($scope) {
            },
            link: function link(scope, iElement, iAttrs) {
                getApiData.fetchJSONP({
                        s: iAttrs.titleToSearch,
                        y: iAttrs.yearToSearch,
                        r: 'JSON',
                        plot: iAttrs.plotToSearch || 'simple',
                        tomatoes: 'false'},
                    function (response) {
                        scope.omdbapiData = response;
                        scope.receivedResponse = true;
                        console.log('Beginning of received response for response.Search ', response.Search, ':\n');
                        console.log('Beginning of received response for scope.omdbapidata.Search ', scope.omdbapiData.Search, ':\n');

                        angular.forEach(response.Search, function (value, key) {
                            console.log("[key/index] ", key, " [value]", value);
                            angular.forEach(value, function (value2, key2) {
                                console.log("-> [key/index] ", key2, " [value]", value2)
                            })
                        });
                        console.log('End of received response!\n');
                    }
                )
            }
        }
    })
    .directive('omdbapiSearchDataInsertion', function (getApiData) {
        return {
            restrict: 'E',
            /*scope: {
             titleToSearch: '=',
             yearToSearch: '=',
             plotToSearch: '@'
             },*/
            transclude: true,
            template: '<div class="wrapper grid_12 alpha omega" ng-transclude></div>',
            controller: function ($scope) {
            },
            link: function link(scope, iElement, iAttrs) {
                getApiData.fetchJSONP({
                        t: iAttrs.titleToSearch,
                        y: iAttrs.yearToSearch,
                        r: 'JSON',
                        plot: iAttrs.plotToSearch || 'full',
                        tomatoes: 'false'},
                    function (response) {
                        scope.omdbapiData = response;
                        scope.receivedResponse = response.Response;
                        var pickRatedPicture = function () {
                            switch(response.Rated) {
                                case 'G':
                                    return 'img/RATED_G.svg';
                                    break;

                                case 'PG':
                                    return 'img/RATED_PG.svg';
                                    break;

                                case 'PG-13':
                                    return 'img/RATED_PG-13.svg';
                                    break;

                                case 'R':
                                    return 'img/RATED_R.svg';
                                    break;

                                case 'TV-Y':
                                    return 'img/RATED_TV-Y.svg';
                                    break;

                                case 'TV-Y7':
                                    return 'img/RATED_TV-Y7.svg';
                                    break;

                                case 'TV-G':
                                    return 'img/RATED_TV-G.svg';
                                    break;

                                case 'TV-PG':
                                    return 'img/RATED_TV-PG.svg';
                                    break;

                                case 'TV-14':
                                    return 'img/RATED_TV-14.svg';
                                    break;

                                case 'TV-MA':
                                    return 'img/RATED_TV-MA.svg';
                                    break;

                                default:
                                    return '';
                            }
                        };
                        scope.ratedPicture = pickRatedPicture();
                        var handleMoviePoster = function() {
                            if(scope.omdbapiData.Poster != 'N/A'){
                                return scope.omdbapiData.Poster;
                            } else {
                                return '';
                            }
                        };
                        scope.moviePoster = handleMoviePoster();

                        scope.omdbapiData.Genre = scope.omdbapiData.Genre.replace(/,/g, " |");

                        /*console.log('Beginning of received response for response ', response, ':\n');
                        console.log('Beginning of received response for scope.omdbapidata ', scope.omdbapiData, ':\n');

                        angular.forEach(response, function (value, key) {
                            console.log("[key/index] ", key, " [value]", value);
                            /*angular.forEach(value, function (value2, key2) {
                             console.log("-> [key/index] ", key2, " [value]", value2)
                             })*//*
                        });
                        console.log('End of received response!\n');*/

                        //      Debug
                        var tempBuf = '';
                        angular.forEach(response, function (value, key) {
                            tempBuf += '<tr>' +
                                '<td>' + key + '</td>' +
                                '<td>' + value + '</td>' +
                                '</tr>';
                        })
                        $('#debug').append(tempBuf);
                        tempBuf = null;
                        // endOf Debug
                    }
                )
            }
        }
    });
