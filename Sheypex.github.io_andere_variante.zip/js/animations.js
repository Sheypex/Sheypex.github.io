'use strict';

/* Animations */


angular.module('myAppAnimations', ['ngAnimate']);

