'use strict';

/* Filters */

angular.module('myAppFilters', []).
  filter('title', [function() {

    }]);
