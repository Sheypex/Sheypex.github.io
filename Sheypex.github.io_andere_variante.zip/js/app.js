'use strict';


// Declare app level module which depends on filters, and services
angular.module('myApp', [
  'ngRoute',
  'ngAnimate',
  'myAppFilters',
  'myAppServices',
  'myAppDirectives',
  'myAppControllers',
  'myAppAnimations'
]).
config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/Movie_Searching',
      {
          templateUrl: 'partials/Movie_Searching.html',
          controller: 'Movie_SearchingCtrl'
      });
  $routeProvider.when('/Neat_Gimmick_Overlay',
      {
          templateUrl: 'partials/Neat_Gimmick_Overlay.html',
          controller: 'Neat_Gimmick_OverlayCtrl'
      });
  $routeProvider.when('/Result_List',
      {
          templateUrl: 'partials/Result_List.html',
          controller: 'Result_ListCtrl'
      });
  $routeProvider.when('/detailed_Result_Info',
      {
          templateUrl: 'partials/Detailed_Result_Info.html',
          controller: 'Detailed_Result_InfoCtrl'
      });
  $routeProvider.otherwise(
      {
          redirectTo: '/Overview',
          templateUrl: 'partials/Overview.html'
      });
}]);
