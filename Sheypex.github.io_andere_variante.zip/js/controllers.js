'use strict';

/* Controllers */
var gRemoveInFinalVersion = true;

angular.module('myAppControllers', [])
    .controller('Movie_SearchingCtrl', ['$scope', function ($scope) {
        /*      Finalization*/
        $scope.removeInFinalVersion = gRemoveInFinalVersion;
        /*EndOf Finalization*/
    }])
    .controller('Neat_Gimmick_OverlayCtrl', ['$scope', function ($scope) {
        /*      Finalization*/
        $scope.removeInFinalVersion = gRemoveInFinalVersion;
        /*EndOf Finalization*/
    }])
    .controller('Result_ListCtrl', ['$scope', '$routeParams', function ($scope, $routeParams) {
        /*      Finalization*/
        $scope.removeInFinalVersion = gRemoveInFinalVersion;
        /*EndOf Finalization*/

        console.log("title = ", $routeParams.title || '????', ", year = ", $routeParams.year || '????');

        /*auf www.omdbapi.com nachsehen für die Bedeutungen:*/
        $scope.searchTitle = $routeParams.title
        $scope.searchYear = $routeParams.year
    }])
    .controller('Detailed_Result_InfoCtrl', ['$scope', '$routeParams', function ($scope, $routeParams) {
        /*      Finalization*/
        $scope.removeInFinalVersion = gRemoveInFinalVersion;
        /*EndOf Finalization*/
        $scope.searchTitle = $routeParams.title
        $scope.searchYear = $routeParams.year
    }]);